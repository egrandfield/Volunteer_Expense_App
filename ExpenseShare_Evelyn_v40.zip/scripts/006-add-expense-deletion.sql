-- Add deletion tracking columns to expenses table
ALTER TABLE expenses 
ADD COLUMN deleted BOOLEAN DEFAULT FALSE,
ADD COLUMN deleted_at TIMESTAMP,
ADD COLUMN deleted_by_user_id INTEGER REFERENCES users(id);

-- Create index for better performance on non-deleted expenses
CREATE INDEX idx_expenses_not_deleted ON expenses (deleted) WHERE deleted = FALSE;
