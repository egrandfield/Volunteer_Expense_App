-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    role VARCHAR(50) NOT NULL CHECK (role IN ('Volunteer', 'Treasurer', 'Admin')),
    weekly_allocation DECIMAL(10,2) DEFAULT 0.00,
    personal_spent DECIMAL(10,2) DEFAULT 0.00,
    group_spent DECIMAL(10,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create expenses table
CREATE TABLE IF NOT EXISTS expenses (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    amount DECIMAL(10,2) NOT NULL,
    description TEXT NOT NULL,
    expense_type VARCHAR(20) NOT NULL CHECK (expense_type IN ('personal', 'group')),
    expense_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create settings table
CREATE TABLE IF NOT EXISTS settings (
    id SERIAL PRIMARY KEY,
    distribution_ratio INTEGER NOT NULL DEFAULT 80,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default settings if none exist
INSERT INTO settings (distribution_ratio) 
SELECT 80 
WHERE NOT EXISTS (SELECT 1 FROM settings);

-- Insert default admin user if none exists
INSERT INTO users (name, email, role, weekly_allocation) 
SELECT 'System Administrator', 'admin@example.com', 'Admin', 100.00
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'admin@example.com');
