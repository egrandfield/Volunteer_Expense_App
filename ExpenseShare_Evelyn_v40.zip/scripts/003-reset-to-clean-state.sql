-- Clear all existing data except the admin user
DELETE FROM expenses;
DELETE FROM users WHERE email != 'admin@expenseshare.com';

-- Reset the admin user to have zero funds
UPDATE users 
SET weekly_allocation = 0.00, 
    personal_spent = 0.00, 
    group_spent = 0.00,
    updated_at = CURRENT_TIMESTAMP
WHERE email = 'admin@expenseshare.com';

-- Ensure we have a clean settings record
DELETE FROM settings;
INSERT INTO settings (distribution_ratio) VALUES (80);
