-- Add deletion tracking columns to fund_history table
ALTER TABLE fund_history 
ADD COLUMN IF NOT EXISTS deleted BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMP NULL,
ADD COLUMN IF NOT EXISTS deleted_by_user_id INTEGER REFERENCES users(id);

-- Add index for better query performance on deleted funds
CREATE INDEX IF NOT EXISTS idx_fund_history_deleted ON fund_history(deleted);
