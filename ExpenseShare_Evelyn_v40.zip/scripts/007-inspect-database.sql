-- Check what tables exist
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public'
ORDER BY table_name;

-- Check users table
SELECT 'USERS TABLE' as table_info;
SELECT id, name, email, role, weekly_allocation, personal_spent, group_spent, created_at
FROM users 
ORDER BY created_at DESC
LIMIT 10;

-- Check expenses table structure and data
SELECT 'EXPENSES TABLE STRUCTURE' as table_info;
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'expenses'
ORDER BY ordinal_position;

SELECT 'EXPENSES TABLE DATA' as table_info;
SELECT id, user_id, amount, description, expense_type, expense_date, created_at, deleted, deleted_at
FROM expenses 
ORDER BY created_at DESC
LIMIT 10;

-- Check fund_history table structure and data
SELECT 'FUND_HISTORY TABLE STRUCTURE' as table_info;
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'fund_history'
ORDER BY ordinal_position;

SELECT 'FUND_HISTORY TABLE DATA' as table_info;
SELECT id, amount, distribution_type, recipient_user_id, recipient_name, added_by_name, description, created_at
FROM fund_history 
ORDER BY created_at DESC
LIMIT 10;

-- Check settings table
SELECT 'SETTINGS TABLE' as table_info;
SELECT * FROM settings ORDER BY created_at DESC LIMIT 5;
