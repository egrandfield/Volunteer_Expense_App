-- Create fund_history table to track all fund additions
CREATE TABLE IF NOT EXISTS fund_history (
  id SERIAL PRIMARY KEY,
  amount DECIMAL(10, 2) NOT NULL,
  distribution_type VARCHAR(20) NOT NULL, -- 'all' or 'individual'
  recipient_user_id INTEGER REFERENCES users(id), -- NULL for 'all' distribution
  recipient_name VARCHAR(255), -- Store name for display
  added_by_user_id INTEGER REFERENCES users(id),
  added_by_name VARCHAR(255), -- Store name for display
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add index for better query performance
CREATE INDEX IF NOT EXISTS idx_fund_history_created_at ON fund_history(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_fund_history_recipient ON fund_history(recipient_user_id);
CREATE INDEX IF NOT EXISTS idx_fund_history_added_by ON fund_history(added_by_user_id);
