-- Insert the correct admin user
INSERT INTO users (name, email, role, weekly_allocation) 
VALUES ('System Administrator', 'admin@expenseshare.com', 'Admin', 100.00)
ON CONFLICT (email) DO UPDATE SET
    name = EXCLUDED.name,
    role = EXCLUDED.role,
    weekly_allocation = EXCLUDED.weekly_allocation;

-- Also add some sample users for testing
INSERT INTO users (name, email, role, weekly_allocation) 
VALUES 
    ('John Volunteer', 'john@example.com', 'Volunteer', 50.00),
    ('Jane Treasurer', 'jane@example.com', 'Treasurer', 75.00),
    ('Bob Helper', 'bob@example.com', 'Volunteer', 60.00)
ON CONFLICT (email) DO NOTHING;
