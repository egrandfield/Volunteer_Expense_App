-- Reset all user allocations to zero except admin
-- Admin should also have zero allocation since they don't spend money

UPDATE users 
SET 
  weekly_allocation = 0,
  personal_spent = 0,
  group_spent = 0,
  updated_at = CURRENT_TIMESTAMP;

-- Verify the reset
SELECT 
  name, 
  email, 
  role, 
  weekly_allocation, 
  personal_spent, 
  group_spent 
FROM users 
ORDER BY created_at;
