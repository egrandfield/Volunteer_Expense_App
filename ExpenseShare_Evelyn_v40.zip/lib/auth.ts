import { getUserByEmail } from "./database"

export async function authenticateUser(email: string) {
  try {
    const user = await getUserByEmail(email)
    return user
  } catch (error) {
    console.error("Authentication error:", error)
    return null
  }
}

export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}
