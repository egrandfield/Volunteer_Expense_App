"use client"

// Simple in-memory store for expenses (in a real app, this would be a database)
class ExpenseStore {
  private expenses: any[] = [] // Removed test expenses

  private listeners: (() => void)[] = []

  getExpenses() {
    return [...this.expenses]
  }

  addExpense(expense: any) {
    this.expenses.unshift(expense)
    this.notifyListeners()
  }

  subscribe(listener: () => void) {
    this.listeners.push(listener)
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener)
    }
  }

  private notifyListeners() {
    this.listeners.forEach((listener) => listener())
  }
}

export const expenseStore = new ExpenseStore()
