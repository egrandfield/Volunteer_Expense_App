import { neon } from "@neondatabase/serverless"

// Create a function to get the SQL connection
function getSQL() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL environment variable is not set")
  }

  return neon(process.env.DATABASE_URL)
}

// User management functions
export async function createUser(userData: {
  name: string
  email: string
  role: "Volunteer" | "Treasurer" | "Admin"
  weeklyAllocation?: number
}) {
  const sql = getSQL()
  const result = await sql`
    INSERT INTO users (name, email, role, weekly_allocation)
    VALUES (${userData.name}, ${userData.email}, ${userData.role}, ${userData.weeklyAllocation || 0})
    RETURNING *
  `
  return result[0]
}

export async function getUserByEmail(email: string) {
  const sql = getSQL()
  const result = await sql`
    SELECT * FROM users WHERE email = ${email}
  `
  return result[0] || null
}

export async function getUserById(id: number) {
  const sql = getSQL()
  const result = await sql`
    SELECT * FROM users WHERE id = ${id}
  `
  return result[0] || null
}

export async function getAllUsers() {
  const sql = getSQL()
  const result = await sql`
    SELECT * FROM users ORDER BY created_at ASC
  `
  return result
}

export async function updateUser(
  id: number,
  updates: {
    name?: string
    email?: string
    role?: string
    weekly_allocation?: number
    personal_spent?: number
    group_spent?: number
  },
) {
  const sql = getSQL()

  // Build the SET clause dynamically
  const updateFields = []
  const values = []

  if (updates.name !== undefined) {
    updateFields.push("name = $" + (values.length + 1))
    values.push(updates.name)
  }
  if (updates.email !== undefined) {
    updateFields.push("email = $" + (values.length + 1))
    values.push(updates.email)
  }
  if (updates.role !== undefined) {
    updateFields.push("role = $" + (values.length + 1))
    values.push(updates.role)
  }
  if (updates.weekly_allocation !== undefined) {
    updateFields.push("weekly_allocation = $" + (values.length + 1))
    values.push(updates.weekly_allocation)
  }
  if (updates.personal_spent !== undefined) {
    updateFields.push("personal_spent = $" + (values.length + 1))
    values.push(updates.personal_spent)
  }
  if (updates.group_spent !== undefined) {
    updateFields.push("group_spent = $" + (values.length + 1))
    values.push(updates.group_spent)
  }

  if (updateFields.length === 0) return null

  const query = `
    UPDATE users 
    SET ${updateFields.join(", ")}, updated_at = CURRENT_TIMESTAMP
    WHERE id = $${values.length + 1}
    RETURNING *
  `

  const result = await sql(query, [...values, id])
  return result[0] || null
}

export async function deleteUser(id: number) {
  const sql = getSQL()
  await sql`DELETE FROM users WHERE id = ${id}`
}

export async function addFundsToUser(userId: number, amount: number, addedByUserId?: number, addedByName?: string) {
  const sql = getSQL()

  // Get recipient user info
  const recipient = await getUserById(userId)
  if (!recipient) throw new Error("Recipient user not found")

  // Update user allocation
  const result = await sql`
    UPDATE users 
    SET weekly_allocation = weekly_allocation + ${amount}, updated_at = CURRENT_TIMESTAMP
    WHERE id = ${userId}
    RETURNING *
  `

  // Record fund addition in history
  await sql`
    INSERT INTO fund_history (amount, distribution_type, recipient_user_id, recipient_name, added_by_user_id, added_by_name, description)
    VALUES (${amount}, 'individual', ${userId}, ${recipient.name}, ${addedByUserId || null}, ${addedByName || "System"}, ${`Funds added to ${recipient.name}'s allocation`})
  `

  return result[0]
}

export async function addFundsToAllUsers(totalAmount: number, addedByUserId?: number, addedByName?: string) {
  const sql = getSQL()
  const users = await getAllUsers()
  const nonAdminUsers = users.filter((user) => user.role !== "Admin")
  const amountPerUser = totalAmount / nonAdminUsers.length

  // Update all non-admin users
  for (const user of nonAdminUsers) {
    await sql`
      UPDATE users 
      SET weekly_allocation = weekly_allocation + ${amountPerUser}, updated_at = CURRENT_TIMESTAMP
      WHERE id = ${user.id}
    `
  }

  // Record fund addition in history
  await sql`
    INSERT INTO fund_history (amount, distribution_type, recipient_user_id, recipient_name, added_by_user_id, added_by_name, description)
    VALUES (${totalAmount}, 'all', ${null}, ${`All team members (${nonAdminUsers.length})`}, ${addedByUserId || null}, ${addedByName || "System"}, ${`$${totalAmount.toFixed(2)} distributed evenly among ${nonAdminUsers.length} team members ($${amountPerUser.toFixed(2)} each)`})
  `

  return await getAllUsers()
}

export async function addPersonalExpense(userId: number, amount: number) {
  const sql = getSQL()
  const result = await sql`
    UPDATE users 
    SET personal_spent = personal_spent + ${amount}, updated_at = CURRENT_TIMESTAMP
    WHERE id = ${userId}
    RETURNING *
  `
  return result[0]
}

export async function addGroupExpenseToAllUsers(totalAmount: number) {
  const sql = getSQL()
  const users = await getAllUsers()
  const amountPerUser = totalAmount / users.length

  await sql`
    UPDATE users 
    SET group_spent = group_spent + ${amountPerUser}, updated_at = CURRENT_TIMESTAMP
  `

  return await getAllUsers()
}

// Expense management functions
export async function createExpense(expenseData: {
  userId: number
  amount: number
  description: string
  expenseType: "personal" | "group"
  expenseDate: string
}) {
  const sql = getSQL()
  const result = await sql`
    INSERT INTO expenses (user_id, amount, description, expense_type, expense_date)
    VALUES (${expenseData.userId}, ${expenseData.amount}, ${expenseData.description}, ${expenseData.expenseType}, ${expenseData.expenseDate})
    RETURNING *
  `
  return result[0]
}

export async function getAllExpenses() {
  const sql = getSQL()
  const result = await sql`
    SELECT e.*, u.name as user_name
    FROM expenses e
    JOIN users u ON e.user_id = u.id
    ORDER BY e.created_at DESC
  `
  return result
}

export async function getExpensesByUser(userId: number) {
  const sql = getSQL()
  const result = await sql`
    SELECT e.*, u.name as user_name
    FROM expenses e
    JOIN users u ON e.user_id = u.id
    WHERE e.user_id = ${userId}
    ORDER BY e.created_at DESC
  `
  return result
}

// Fund history functions
export async function getAllFundHistory() {
  const sql = getSQL()
  const result = await sql`
    SELECT * FROM fund_history
    ORDER BY created_at DESC
  `
  return result
}

export async function getFinancialHistory() {
  const sql = getSQL()

  // Get expenses
  const expenses = await sql`
    SELECT 
      'expense' as type,
      e.id,
      e.amount,
      e.description,
      e.expense_type as category,
      u.name as user_name,
      e.expense_date as date,
      e.created_at
    FROM expenses e
    JOIN users u ON e.user_id = u.id
  `

  // Get fund additions
  const fundAdditions = await sql`
    SELECT 
      'fund_addition' as type,
      f.id,
      f.amount,
      f.description,
      f.distribution_type as category,
      f.recipient_name as user_name,
      f.added_by_name,
      DATE(f.created_at) as date,
      f.created_at
    FROM fund_history f
  `

  // Combine and sort by date
  const combined = [...expenses, ...fundAdditions].sort(
    (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime(),
  )

  return combined
}

// Settings management functions
export async function getSettings() {
  const sql = getSQL()
  const result = await sql`
    SELECT * FROM settings ORDER BY created_at DESC LIMIT 1
  `
  return result[0] || { distribution_ratio: 80 }
}

export async function updateSettings(distributionRatio: number) {
  const sql = getSQL()
  const result = await sql`
    UPDATE settings 
    SET distribution_ratio = ${distributionRatio}, updated_at = CURRENT_TIMESTAMP
    WHERE id = (SELECT id FROM settings ORDER BY created_at DESC LIMIT 1)
    RETURNING *
  `
  return result[0]
}

// Financial calculation functions
export async function getTotalKitty() {
  const sql = getSQL()
  const result = await sql`
    SELECT COALESCE(SUM(weekly_allocation), 0) as total
    FROM users
  `
  return Number(result[0].total)
}

export async function getAvailableGroupFunds() {
  const sql = getSQL()
  const settings = await getSettings()
  const totalKitty = await getTotalKitty()
  const groupPercentage = settings.distribution_ratio / 100
  const maxGroupFunds = totalKitty * groupPercentage

  const result = await sql`
    SELECT COALESCE(SUM(group_spent), 0) as total_group_spent
    FROM users
  `
  const totalGroupSpent = Number(result[0].total_group_spent)

  return Math.max(0, maxGroupFunds - totalGroupSpent)
}

export async function getUserFinancials(userId: number) {
  const user = await getUserById(userId)
  if (!user) return null

  const settings = await getSettings()
  const groupPercentage = settings.distribution_ratio / 100
  const personalPercentage = 1 - groupPercentage

  const personalAllocation = Number(user.weekly_allocation) * personalPercentage
  const groupAllocation = Number(user.weekly_allocation) * groupPercentage
  const personalSpent = Number(user.personal_spent)
  const groupSpent = Number(user.group_spent)

  return {
    totalAllocation: Number(user.weekly_allocation),
    personalAllocation,
    groupAllocation,
    personalSpent,
    groupSpent,
    personalRemaining: personalAllocation - personalSpent,
    maxPersonalExpense: personalAllocation,
  }
}
