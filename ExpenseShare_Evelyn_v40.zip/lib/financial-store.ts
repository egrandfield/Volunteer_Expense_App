"use client"

// Financial management store
class FinancialStore {
  // Update the initial volunteers array to include groupSpent tracking
  private volunteers: any[] = []

  private settings = {
    distributionRatio: 80, // 80% for group expenses, 20% for personal
  }

  private listeners: (() => void)[] = []

  // Calculate total kitty (sum of all allocations)
  getTotalKitty() {
    return this.volunteers.reduce((sum, volunteer) => sum + volunteer.weeklyAllocation, 0)
  }

  // Calculate available group funds (80% of total kitty minus group expenses already spent)
  getAvailableGroupFunds() {
    const totalKitty = this.getTotalKitty()
    const groupPercentage = this.settings.distributionRatio / 100
    const maxGroupFunds = totalKitty * groupPercentage

    // Calculate how much group money has been spent
    const groupSpent = this.volunteers.reduce((sum, volunteer) => {
      return sum + (volunteer.groupSpent || 0)
    }, 0)

    return Math.max(0, maxGroupFunds - groupSpent)
  }

  // Get volunteer data
  getVolunteers() {
    return [...this.volunteers]
  }

  // Get settings
  getSettings() {
    return { ...this.settings }
  }

  // Update settings
  updateSettings(newSettings: Partial<typeof this.settings>) {
    this.settings = { ...this.settings, ...newSettings }
    this.notifyListeners()
  }

  // Add funds to a specific volunteer's allocation
  addFundsToVolunteer(volunteerId: string, amount: number) {
    const volunteer = this.volunteers.find((v) => v.id === volunteerId)
    if (volunteer) {
      volunteer.weeklyAllocation += amount
      this.notifyListeners()
    }
  }

  // Add funds evenly to all volunteers
  addFundsEvenly(totalAmount: number) {
    const amountPerVolunteer = totalAmount / this.volunteers.length
    this.volunteers.forEach((volunteer) => {
      volunteer.weeklyAllocation += amountPerVolunteer
    })
    this.notifyListeners()
  }

  // Process a personal expense
  addPersonalExpense(volunteerId: string, amount: number) {
    const volunteer = this.volunteers.find((v) => v.id === volunteerId)
    if (volunteer) {
      volunteer.personalSpent += amount
      this.notifyListeners()
      return true
    }
    return false
  }

  // Process a group expense (deduct from group funds only)
  addGroupExpense(amount: number) {
    const amountPerVolunteer = amount / this.volunteers.length
    this.volunteers.forEach((volunteer) => {
      // Track group spending separately from personal spending
      if (!volunteer.groupSpent) volunteer.groupSpent = 0
      volunteer.groupSpent += amountPerVolunteer
    })
    this.notifyListeners()
    return true
  }

  // Get individual volunteer financial info
  getVolunteerFinancials(volunteerId: string) {
    const volunteer = this.volunteers.find((v) => v.id === volunteerId)
    if (!volunteer) return null

    const groupPercentage = this.settings.distributionRatio / 100
    const personalPercentage = 1 - groupPercentage

    const personalAllocation = volunteer.weeklyAllocation * personalPercentage
    const groupAllocation = volunteer.weeklyAllocation * groupPercentage

    const personalSpent = volunteer.personalSpent || 0
    const groupSpent = volunteer.groupSpent || 0

    return {
      totalAllocation: volunteer.weeklyAllocation,
      personalAllocation,
      groupAllocation,
      personalSpent,
      groupSpent,
      personalRemaining: personalAllocation - personalSpent,
      maxPersonalExpense: personalAllocation, // Can spend up to full personal allocation
    }
  }

  // Set weekly allocation for all volunteers
  setWeeklyAllocation(amount: number) {
    this.volunteers.forEach((volunteer) => {
      volunteer.weeklyAllocation = amount
    })
    this.notifyListeners()
  }

  // Add methods for user management:

  // Add a new volunteer or treasurer
  addUser(userData: { name: string; email: string; role: "Volunteer" | "Treasurer" }) {
    const newUser = {
      id: Date.now().toString(),
      name: userData.name,
      email: userData.email,
      role: userData.role,
      weeklyAllocation: 0, // Start with $0 allocation - admin adds funds separately
      personalSpent: 0,
      groupSpent: 0, // Track group expenses separately
    }
    this.volunteers.push(newUser)
    this.notifyListeners()
    return newUser
  }

  // Remove a user
  removeUser(userId: string) {
    this.volunteers = this.volunteers.filter((v) => v.id !== userId)
    this.notifyListeners()
  }

  // Update user details
  updateUser(
    userId: string,
    updates: Partial<{ name: string; email: string; role: string; weeklyAllocation: number }>,
  ) {
    const user = this.volunteers.find((v) => v.id === userId)
    if (user) {
      Object.assign(user, updates)
      this.notifyListeners()
    }
  }

  // Get user by ID
  getUserById(userId: string) {
    return this.volunteers.find((v) => v.id === userId)
  }

  subscribe(listener: () => void) {
    this.listeners.push(listener)
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener)
    }
  }

  private notifyListeners() {
    this.listeners.forEach((listener) => listener())
  }
}

export const financialStore = new FinancialStore()
