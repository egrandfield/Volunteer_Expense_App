"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DollarSign, TrendingUp, Users, PieChart } from "lucide-react"

interface DashboardData {
  totalKitty: number
  availableGroupFunds: number
  totalUsers: number
  settings: { distribution_ratio: number }
}

export default function KittyStatus() {
  const [kittyData, setKittyData] = useState<DashboardData>({
    totalKitty: 0,
    availableGroupFunds: 0,
    totalUsers: 0,
    settings: { distribution_ratio: 80 },
  })
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const loadKittyData = async () => {
    try {
      setError(null)
      const response = await fetch("/api/dashboard")

      if (!response.ok) {
        throw new Error(`Failed to load dashboard data: ${response.statusText}`)
      }

      const data = await response.json()

      if (data.error) {
        throw new Error(data.error)
      }

      setKittyData({
        totalKitty: data.totalKitty || 0,
        availableGroupFunds: data.availableGroupFunds || 0,
        totalUsers: data.totalUsers || 0,
        settings: data.settings || { distribution_ratio: 80 },
      })
    } catch (error) {
      console.error("Error loading kitty data:", error)
      setError(error instanceof Error ? error.message : "Failed to load data")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    loadKittyData()
  }, [])

  if (isLoading) {
    return (
      <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
        <CardContent className="pt-6">
          <div className="text-center">Loading kitty status...</div>
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Card className="bg-gradient-to-r from-red-50 to-orange-50 border-red-200">
        <CardContent className="pt-6">
          <div className="text-center text-red-600">
            <p>Error loading kitty data</p>
            <p className="text-sm mt-2">{error}</p>
            <button onClick={loadKittyData} className="mt-3 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700">
              Retry
            </button>
          </div>
        </CardContent>
      </Card>
    )
  }

  const groupPercentage = kittyData.settings.distribution_ratio
  const personalPercentage = 100 - groupPercentage
  const totalGroupAllocation = (kittyData.totalKitty * groupPercentage) / 100
  const totalPersonalAllocation = (kittyData.totalKitty * personalPercentage) / 100
  const groupSpent = totalGroupAllocation - kittyData.availableGroupFunds

  return (
    <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2 text-green-800">
          <DollarSign className="h-5 w-5" />
          <span>Team Kitty Status</span>
        </CardTitle>
        <CardDescription>Overall financial overview for the volunteer team</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-4 w-4 text-green-600" />
              <span className="text-sm font-medium text-green-700">Total Kitty</span>
            </div>
            <div className="text-2xl font-bold text-green-800">${kittyData.totalKitty.toFixed(2)}</div>
            <p className="text-xs text-green-600">Combined allocations</p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <PieChart className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-700">Group Pool</span>
            </div>
            <div className="text-2xl font-bold text-blue-800">${totalGroupAllocation.toFixed(2)}</div>
            <p className="text-xs text-blue-600">{groupPercentage}% of total kitty</p>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-blue-500 h-2 rounded-l-full"
                style={{
                  width: `${totalGroupAllocation > 0 ? (kittyData.availableGroupFunds / totalGroupAllocation) * 100 : 0}%`,
                }}
              ></div>
              <div
                className="bg-red-500 h-2 rounded-r-full"
                style={{ width: `${totalGroupAllocation > 0 ? (groupSpent / totalGroupAllocation) * 100 : 0}%` }}
              ></div>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-blue-600">Available: ${kittyData.availableGroupFunds.toFixed(2)}</span>
              <span className="text-red-600">Spent: ${groupSpent.toFixed(2)}</span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4 text-purple-600" />
              <span className="text-sm font-medium text-purple-700">Personal Pool</span>
            </div>
            <div className="text-2xl font-bold text-purple-800">${totalPersonalAllocation.toFixed(2)}</div>
            <p className="text-xs text-purple-600">{personalPercentage}% of total kitty</p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4 text-gray-600" />
              <span className="text-sm font-medium text-gray-700">Team Size</span>
            </div>
            <div className="text-2xl font-bold text-gray-800">{kittyData.totalUsers}</div>
            <p className="text-xs text-gray-600">Active members</p>
          </div>
        </div>

        <div className="mt-4 p-3 bg-white rounded-lg border">
          <h4 className="font-medium text-gray-800 mb-2">Distribution Breakdown</h4>
          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <span>Group Expenses: {groupPercentage}%</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
              <span>Personal Expenses: {personalPercentage}%</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
