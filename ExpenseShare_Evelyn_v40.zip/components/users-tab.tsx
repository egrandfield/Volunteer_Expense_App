"use client"

import UserManagement from "@/components/user-management"

export default function UsersTab() {
  return <UserManagement />
}
