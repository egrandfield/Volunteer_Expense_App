"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { PlusCircle, Trash2, Edit, Mail } from "lucide-react"

export default function UserManagement() {
  const [users, setUsers] = useState<any[]>([])
  const [showAddUserModal, setShowAddUserModal] = useState(false)
  const [showEditUserModal, setShowEditUserModal] = useState(false)
  const [editingUser, setEditingUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)

  const [userForm, setUserForm] = useState({
    name: "",
    email: "",
    role: "Volunteer" as "Volunteer" | "Treasurer",
  })

  const { toast } = useToast()

  const loadUsers = async () => {
    try {
      const response = await fetch("/api/users")
      if (!response.ok) {
        throw new Error("Failed to load users")
      }
      const userData = await response.json()
      setUsers(userData)
    } catch (error) {
      console.error("Error loading users:", error)
      toast({
        title: "Error loading users",
        description: "Failed to load user data.",
        variant: "destructive",
      })
    }
  }

  useEffect(() => {
    loadUsers()
  }, [])

  const handleAddUser = async () => {
    if (!userForm.name.trim() || !userForm.email.trim()) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      })
      return
    }

    // Check if email already exists
    const existingUser = users.find((u) => u.email === userForm.email)
    if (existingUser) {
      toast({
        title: "Email already exists",
        description: "A user with this email already exists.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: userForm.name,
          email: userForm.email,
          role: userForm.role,
          weeklyAllocation: 0, // Explicitly set to zero
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to create user")
      }

      const newUser = await response.json()

      setUserForm({ name: "", email: "", role: "Volunteer" })
      setShowAddUserModal(false)

      // Reload users to get updated list
      await loadUsers()

      toast({
        title: "User added",
        description: `${newUser.name} has been added as a ${newUser.role}.`,
      })
    } catch (error) {
      console.error("Error adding user:", error)
      toast({
        title: "Error adding user",
        description: error instanceof Error ? error.message : "Failed to add user. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleEditUser = async () => {
    if (!editingUser || !userForm.name.trim() || !userForm.email.trim()) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch(`/api/users/${editingUser.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: userForm.name,
          email: userForm.email,
          role: userForm.role,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to update user")
      }

      setEditingUser(null)
      setShowEditUserModal(false)
      setUserForm({ name: "", email: "", role: "Volunteer" })

      // Reload users to get updated list
      await loadUsers()

      toast({
        title: "User updated",
        description: `${userForm.name}'s information has been updated.`,
      })
    } catch (error) {
      console.error("Error updating user:", error)
      toast({
        title: "Error updating user",
        description: error instanceof Error ? error.message : "Failed to update user. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleRemoveUser = async (userId: number, userName: string) => {
    if (confirm(`Are you sure you want to remove ${userName}? This action cannot be undone.`)) {
      setIsLoading(true)
      try {
        const response = await fetch(`/api/users/${userId}`, {
          method: "DELETE",
        })

        if (!response.ok) {
          const error = await response.json()
          throw new Error(error.error || "Failed to remove user")
        }

        // Reload users to get updated list
        await loadUsers()

        toast({
          title: "User removed",
          description: `${userName} has been removed from the system.`,
        })
      } catch (error) {
        console.error("Error removing user:", error)
        toast({
          title: "Error removing user",
          description: error instanceof Error ? error.message : "Failed to remove user. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }
  }

  const openEditModal = (user: any) => {
    setEditingUser(user)
    setUserForm({
      name: user.name,
      email: user.email,
      role: user.role,
    })
    setShowEditUserModal(true)
  }

  const generateLoginInfo = (user: any) => {
    const loginInfo = `Login Email: ${user.email}\nRole: ${user.role}\nAllocation: $${Number(user.weekly_allocation).toFixed(2)}`
    navigator.clipboard.writeText(loginInfo)
    toast({
      title: "Login info copied",
      description: "User login information copied to clipboard.",
    })
  }

  const calculatePersonalRemaining = (user: any) => {
    // This should match the calculation in the backend
    const settings = { distribution_ratio: 80 } // Default, should be fetched from API
    const personalPercentage = (100 - settings.distribution_ratio) / 100
    const personalAllocation = Number(user.weekly_allocation) * personalPercentage
    const personalSpent = Number(user.personal_spent)
    return personalAllocation - personalSpent
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>User Management</CardTitle>
            <CardDescription>Manage volunteers and treasurers</CardDescription>
          </div>
          <Button onClick={() => setShowAddUserModal(true)} disabled={isLoading}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add User
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {users.length === 0 ? (
              <p className="text-center text-gray-500 py-8">
                No users added yet. Add your first volunteer or treasurer!
              </p>
            ) : (
              users.map((user) => (
                <div key={user.id} className="flex items-center justify-between border rounded-lg p-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3">
                      <div>
                        <p className="font-medium">{user.name}</p>
                        <p className="text-sm text-gray-500">{user.email}</p>
                      </div>
                      <div
                        className={`px-2 py-1 rounded-full text-xs ${
                          user.role === "Treasurer"
                            ? "bg-blue-100 text-blue-800"
                            : user.role === "Admin"
                              ? "bg-purple-100 text-purple-800"
                              : "bg-green-100 text-green-800"
                        }`}
                      >
                        {user.role}
                      </div>
                    </div>
                    <div className="mt-2 text-sm text-gray-600">
                      Allocation: ${Number(user.weekly_allocation).toFixed(2)} | Personal Remaining: $
                      {calculatePersonalRemaining(user).toFixed(2)}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm" onClick={() => generateLoginInfo(user)} disabled={isLoading}>
                      <Mail className="h-4 w-4" />
                    </Button>
                    {user.role !== "Admin" && (
                      <>
                        <Button variant="outline" size="sm" onClick={() => openEditModal(user)} disabled={isLoading}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleRemoveUser(user.id, user.name)}
                          disabled={isLoading}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Add User Modal */}
      {showAddUserModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Add New User</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="user-name">Full Name</Label>
                <Input
                  id="user-name"
                  placeholder="Enter full name"
                  value={userForm.name}
                  onChange={(e) => setUserForm({ ...userForm, name: e.target.value })}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="user-email">Email Address</Label>
                <Input
                  id="user-email"
                  type="email"
                  placeholder="Enter email address"
                  value={userForm.email}
                  onChange={(e) => setUserForm({ ...userForm, email: e.target.value })}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="user-role">Role</Label>
                <Select
                  value={userForm.role}
                  onValueChange={(value: "Volunteer" | "Treasurer") => setUserForm({ ...userForm, role: value })}
                  disabled={isLoading}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Volunteer">Volunteer</SelectItem>
                    <SelectItem value="Treasurer">Treasurer</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="bg-blue-50 p-3 rounded-md">
                <p className="text-sm text-blue-800">
                  <strong>Note:</strong> New users start with $0 allocation
                </p>
                <p className="text-xs text-blue-600 mt-1">Use "Add Funds" to allocate money to users after creation</p>
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowAddUserModal(false)} disabled={isLoading}>
                  Cancel
                </Button>
                <Button onClick={handleAddUser} disabled={isLoading}>
                  {isLoading ? "Adding..." : "Add User"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {showEditUserModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Edit User</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="edit-user-name">Full Name</Label>
                <Input
                  id="edit-user-name"
                  placeholder="Enter full name"
                  value={userForm.name}
                  onChange={(e) => setUserForm({ ...userForm, name: e.target.value })}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-user-email">Email Address</Label>
                <Input
                  id="edit-user-email"
                  type="email"
                  placeholder="Enter email address"
                  value={userForm.email}
                  onChange={(e) => setUserForm({ ...userForm, email: e.target.value })}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-user-role">Role</Label>
                <Select
                  value={userForm.role}
                  onValueChange={(value: "Volunteer" | "Treasurer") => setUserForm({ ...userForm, role: value })}
                  disabled={isLoading}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Volunteer">Volunteer</SelectItem>
                    <SelectItem value="Treasurer">Treasurer</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowEditUserModal(false)} disabled={isLoading}>
                  Cancel
                </Button>
                <Button onClick={handleEditUser} disabled={isLoading}>
                  {isLoading ? "Updating..." : "Update User"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
