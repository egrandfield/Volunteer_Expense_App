"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { LogOut } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import AdminDashboard from "@/components/admin-dashboard"
import TreasurerDashboard from "@/components/treasurer-dashboard"
import VolunteerDashboard from "@/components/volunteer-dashboard"
import FinancialHistoryTab from "@/components/financial-history-tab"
import UsersTab from "@/components/users-tab"

interface DashboardLayoutProps {
  user: any
  children?: React.ReactNode
}

export default function DashboardLayout({ user, children }: DashboardLayoutProps) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("dashboard")
  const { toast } = useToast()

  const handleLogout = () => {
    // Clear all user data from localStorage
    localStorage.removeItem("user")
    localStorage.removeItem("expenseData")

    // Show logout confirmation
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    })

    // Redirect to login page
    router.push("/")
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-xl font-bold">ExpenseShare</h1>
          </div>
          <div className="flex items-center space-x-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/placeholder-user.jpg" alt={user.name} />
                    <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user.name}</p>
                    <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                    <p className="text-xs leading-none text-muted-foreground mt-1">Role: {user.role}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="cursor-pointer">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      {/* Main content */}
      <div className="container mx-auto px-4 py-6">
        <Tabs defaultValue="dashboard" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList
            className={`grid w-full ${user.role === "Admin" ? "max-w-md grid-cols-3" : "max-w-sm grid-cols-2"}`}
          >
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
            {user.role === "Admin" && <TabsTrigger value="users">Users</TabsTrigger>}
          </TabsList>
          <TabsContent value="dashboard" className="space-y-4">
            {user?.role === "Admin" && <AdminDashboard user={user} onSwitchTab={setActiveTab} />}
            {user?.role === "Treasurer" && <TreasurerDashboard user={user} />}
            {user?.role === "Volunteer" && <VolunteerDashboard user={user} />}
          </TabsContent>
          <TabsContent value="history" className="space-y-4">
            <FinancialHistoryTab user={user} />
          </TabsContent>
          {user.role === "Admin" && (
            <TabsContent value="users" className="space-y-4">
              <UsersTab />
            </TabsContent>
          )}
        </Tabs>
      </div>
    </div>
  )
}
