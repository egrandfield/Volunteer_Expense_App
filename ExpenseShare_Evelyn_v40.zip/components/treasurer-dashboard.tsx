"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { PlusCircle, DollarSign, PieChart } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import KittyStatus from "@/components/kitty-status"

// Safely format a number as currency
function fmt(value: number | null | undefined) {
  return (value ?? 0).toFixed(2)
}

export default function TreasurerDashboard({ user }: { user: any }) {
  const [showExpenseModal, setShowExpenseModal] = useState(false)
  const [loading, setLoading] = useState(true)
  const [financialData, setFinancialData] = useState({
    totalKitty: 0,
    availableGroupFunds: 0,
    personalFinancials: null as any,
  })

  const [expenseForm, setExpenseForm] = useState({
    amount: "",
    description: "",
    type: "personal", // personal or group
    date: new Date().toISOString().split("T")[0],
  })

  const { toast } = useToast()

  // Load financial data from database
  const loadFinancialData = async () => {
    try {
      setLoading(true)

      // Get dashboard data (total kitty, available group funds)
      const dashboardResponse = await fetch("/api/dashboard")
      const dashboardData = await dashboardResponse.json()

      // Get user's personal financial data
      const userResponse = await fetch(`/api/users/${user.id}`)
      const userData = await userResponse.json()

      setFinancialData({
        totalKitty: dashboardData.totalKitty || 0,
        availableGroupFunds: dashboardData.availableGroupFunds || 0,
        personalFinancials: userData,
      })
    } catch (error) {
      console.error("Failed to load financial data:", error)
      toast({
        title: "Error loading data",
        description: "Failed to load your financial information.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadFinancialData()
  }, [user.id])

  const handleAddExpense = async () => {
    const amount = Number.parseFloat(expenseForm.amount)

    if (!amount || amount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid amount greater than 0.",
        variant: "destructive",
      })
      return
    }

    if (!expenseForm.description.trim()) {
      toast({
        title: "Missing description",
        description: "Please enter a description for the expense.",
        variant: "destructive",
      })
      return
    }

    // Check limits based on expense type
    if (expenseForm.type === "personal") {
      if (!financialData.personalFinancials || amount > financialData.personalFinancials.personalRemaining) {
        toast({
          title: "Expense exceeds personal allocation",
          description: `You only have $${financialData.personalFinancials?.personalRemaining?.toFixed(2) || "0.00"} remaining in your personal allocation.`,
          variant: "destructive",
        })
        return
      }
    } else {
      if (amount > financialData.availableGroupFunds) {
        toast({
          title: "Expense exceeds group fund allocation",
          description: `Only $${financialData.availableGroupFunds.toFixed(2)} is available for group expenses.`,
          variant: "destructive",
        })
        return
      }
    }

    try {
      // Add expense via API
      const response = await fetch("/api/expenses", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: user.id,
          amount: amount,
          description: expenseForm.description,
          expenseType: expenseForm.type,
          expenseDate: expenseForm.date,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to add expense")
      }

      // Reset form
      setExpenseForm({
        amount: "",
        description: "",
        type: "personal",
        date: new Date().toISOString().split("T")[0],
      })

      setShowExpenseModal(false)

      // Reload financial data
      await loadFinancialData()

      toast({
        title: "Expense added",
        description: `${expenseForm.type === "group" ? "Group" : "Personal"} expense of $${amount.toFixed(2)} has been recorded.`,
      })
    } catch (error) {
      console.error("Failed to add expense:", error)
      toast({
        title: "Error adding expense",
        description: "Failed to record the expense. Please try again.",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="text-center py-8">
          <p>Loading your financial data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* User Info Header */}
      <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
        <CardContent className="pt-6">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
              {user.name
                .split(" ")
                .map((n) => n[0])
                .join("")
                .toUpperCase()}
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">{user.name}</h2>
              <p className="text-sm text-gray-600">{user.email}</p>
              <p className="text-sm font-medium text-green-600">Role: {user.role}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Kitty Status - Always shown first */}
      <KittyStatus />

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-2">
        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-green-700">Available Group Funds</CardTitle>
            <DollarSign className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-800">${fmt(financialData.availableGroupFunds)}</div>
            <p className="text-xs text-green-600">80% of kitty available for group expenses</p>
            <div className="mt-2 space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-green-600">Available: ${fmt(financialData.availableGroupFunds)}</span>
                <span className="text-red-600">
                  Spent: ${fmt(financialData.totalKitty * 0.8 - financialData.availableGroupFunds)}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-green-500 h-2 rounded-l-full"
                  style={{
                    width: `${financialData.totalKitty > 0 ? (financialData.availableGroupFunds / (financialData.totalKitty * 0.8)) * 100 : 0}%`,
                  }}
                ></div>
                <div
                  className="bg-red-500 h-2 rounded-r-full"
                  style={{
                    width: `${financialData.totalKitty > 0 ? ((financialData.totalKitty * 0.8 - financialData.availableGroupFunds) / (financialData.totalKitty * 0.8)) * 100 : 0}%`,
                  }}
                ></div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-purple-700">Your Personal Remaining</CardTitle>
            <PieChart className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-800">
              ${fmt(financialData.personalFinancials?.personalRemaining)}
            </div>
            <p className="text-xs text-purple-600">Your remaining personal funds</p>
            {financialData.personalFinancials?.personalAllocation === 0 ? (
              <p className="text-xs text-orange-600 mt-2">No personal allocation yet. Ask admin to add funds.</p>
            ) : (
              <div className="mt-2 space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-purple-600">
                    Remaining: ${fmt(financialData.personalFinancials?.personalRemaining)}
                  </span>
                  <span className="text-red-600">Spent: ${fmt(financialData.personalFinancials?.personalSpent)}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-purple-500 h-2 rounded-full"
                    style={{
                      width: `${financialData.personalFinancials && financialData.personalFinancials.personalAllocation > 0 ? (financialData.personalFinancials.personalRemaining / financialData.personalFinancials.personalAllocation) * 100 : 0}%`,
                    }}
                  ></div>
                  <div
                    className="bg-red-500 h-2 rounded-r-full -mt-2"
                    style={{
                      width: `${financialData.personalFinancials && financialData.personalFinancials.personalAllocation > 0 ? (financialData.personalFinancials.personalSpent / financialData.personalFinancials.personalAllocation) * 100 : 0}%`,
                      marginLeft: `${financialData.personalFinancials && financialData.personalFinancials.personalAllocation > 0 ? (financialData.personalFinancials.personalRemaining / financialData.personalFinancials.personalAllocation) * 100 : 0}%`,
                    }}
                  ></div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Your Financial Breakdown</CardTitle>
            <CardDescription>Personal vs Group allocation details</CardDescription>
          </div>
          <Button
            onClick={() => setShowExpenseModal(true)}
            disabled={!financialData.personalFinancials || financialData.personalFinancials.personalAllocation === 0}
          >
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Expense
          </Button>
        </CardHeader>
        <CardContent>
          {financialData.personalFinancials ? (
            financialData.personalFinancials.personalAllocation === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No funds allocated yet.</p>
                <p className="text-sm text-muted-foreground mt-2">Ask an admin to add funds to your account.</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Personal Allocation (20%)</p>
                    <p className="text-2xl font-bold">${fmt(financialData.personalFinancials?.personalAllocation)}</p>
                    <p className="text-xs text-muted-foreground">
                      Spent: ${financialData.personalFinancials.personalSpent.toFixed(2)} | Remaining: $
                      {financialData.personalFinancials.personalRemaining.toFixed(2)}
                    </p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Group Contribution (80%)</p>
                    <p className="text-2xl font-bold">${fmt(financialData.personalFinancials?.groupAllocation)}</p>
                    <p className="text-xs text-muted-foreground">
                      Your share of group expenses: ${financialData.personalFinancials.groupSpent.toFixed(2)}
                    </p>
                  </div>
                </div>
              </div>
            )
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Unable to load financial data.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add Expense Modal */}
      {showExpenseModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Add Expense</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="expense-type">Expense Type</Label>
                <Select
                  value={expenseForm.type}
                  onValueChange={(value) => setExpenseForm({ ...expenseForm, type: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select expense type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="personal">Personal Expense</SelectItem>
                    <SelectItem value="group">Group Expense</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  {expenseForm.type === "personal"
                    ? `Available: $${financialData.personalFinancials?.personalRemaining?.toFixed(2) || "0.00"}`
                    : `Available for group: $${financialData.availableGroupFunds.toFixed(2)}`}
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="expense-amount">Amount ($)</Label>
                <Input
                  id="expense-amount"
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={expenseForm.amount}
                  onChange={(e) => setExpenseForm({ ...expenseForm, amount: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="expense-description">Description</Label>
                <Textarea
                  id="expense-description"
                  placeholder="What was this expense for?"
                  value={expenseForm.description}
                  onChange={(e) => setExpenseForm({ ...expenseForm, description: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="expense-date">Date</Label>
                <Input
                  id="expense-date"
                  type="date"
                  value={expenseForm.date}
                  onChange={(e) => setExpenseForm({ ...expenseForm, date: e.target.value })}
                />
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowExpenseModal(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddExpense}>Add Expense</Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
