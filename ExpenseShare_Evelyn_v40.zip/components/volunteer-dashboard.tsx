"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { PlusCircle, DollarSign, PieChart } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import KittyStatus from "@/components/kitty-status"

export default function VolunteerDashboard({ user }: { user: any }) {
  const [showExpenseModal, setShowExpenseModal] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [financialData, setFinancialData] = useState({
    totalKitty: 0,
    availableGroupFunds: 0,
    personalFinancials: null as any,
    settings: { distribution_ratio: 80 },
  })

  const [expenseForm, setExpenseForm] = useState({
    amount: "",
    description: "",
    date: new Date().toISOString().split("T")[0],
  })

  const { toast } = useToast()

  const loadFinancialData = async () => {
    try {
      const [dashboardResponse, userFinancialsResponse, settingsResponse] = await Promise.all([
        fetch("/api/dashboard"),
        fetch(`/api/users/${user.id}`),
        fetch("/api/settings"),
      ])

      if (!dashboardResponse.ok || !userFinancialsResponse.ok || !settingsResponse.ok) {
        throw new Error("Failed to fetch financial data")
      }

      const [dashboardData, userFinancials, settings] = await Promise.all([
        dashboardResponse.json(),
        userFinancialsResponse.json(),
        settingsResponse.json(),
      ])

      setFinancialData({
        totalKitty: dashboardData.totalKitty,
        availableGroupFunds: dashboardData.availableGroupFunds,
        personalFinancials: userFinancials,
        settings,
      })
    } catch (error) {
      console.error("Error loading financial data:", error)
      toast({
        title: "Error loading data",
        description: "Failed to load financial information.",
        variant: "destructive",
      })
    }
  }

  useEffect(() => {
    loadFinancialData()
  }, [user.id])

  const handleAddExpense = async () => {
    const amount = Number.parseFloat(expenseForm.amount)

    if (!amount || amount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid amount greater than 0.",
        variant: "destructive",
      })
      return
    }

    if (!expenseForm.description.trim()) {
      toast({
        title: "Missing description",
        description: "Please enter a description for the expense.",
        variant: "destructive",
      })
      return
    }

    if (!financialData.personalFinancials || amount > financialData.personalFinancials.personalRemaining) {
      toast({
        title: "Expense exceeds personal allocation",
        description: `You only have $${financialData.personalFinancials?.personalRemaining.toFixed(2) || "0.00"} remaining in your personal allocation. Maximum allowed: $${financialData.personalFinancials?.personalRemaining.toFixed(2) || "0.00"}`,
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch("/api/expenses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          amount,
          description: expenseForm.description,
          expenseType: "personal",
          expenseDate: expenseForm.date,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        if (error.error === "Insufficient personal funds") {
          toast({
            title: "Expense exceeds personal allocation",
            description: `You only have $${error.available.toFixed(2)} remaining in your personal allocation. Maximum allowed: $${error.available.toFixed(2)}`,
            variant: "destructive",
          })
        } else {
          throw new Error(error.error || "Failed to add expense")
        }
        return
      }

      // Reset form
      setExpenseForm({
        amount: "",
        description: "",
        date: new Date().toISOString().split("T")[0],
      })

      setShowExpenseModal(false)

      // Reload financial data
      await loadFinancialData()

      toast({
        title: "Expense added",
        description: `Personal expense of $${amount.toFixed(2)} has been recorded.`,
      })
    } catch (error) {
      console.error("Error adding expense:", error)
      toast({
        title: "Error adding expense",
        description: error instanceof Error ? error.message : "Failed to add expense. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* User Info Header */}
      <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
        <CardContent className="pt-6">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
              {user.name
                .split(" ")
                .map((n) => n[0])
                .join("")
                .toUpperCase()}
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">{user.name}</h2>
              <p className="text-sm text-gray-600">{user.email}</p>
              <p className="text-sm font-medium text-purple-600">Role: {user.role}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Kitty Status - Always shown first */}
      <KittyStatus />

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-l-4 border-l-purple-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-purple-700">Your Personal Allocation</CardTitle>
            <DollarSign className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-800">
              ${financialData.personalFinancials?.personalAllocation.toFixed(2) || "0.00"}
            </div>
            <p className="text-xs text-purple-600">
              {100 - financialData.settings.distribution_ratio}% of your weekly allocation
            </p>
            <div className="mt-4 space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-red-600">
                  Used: ${financialData.personalFinancials?.personalSpent.toFixed(2) || "0.00"}
                </span>
                <span className="text-purple-600">
                  Remaining: ${financialData.personalFinancials?.personalRemaining.toFixed(2) || "0.00"}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-purple-500 h-3 rounded-full"
                  style={{
                    width: `${financialData.personalFinancials && financialData.personalFinancials.personalAllocation > 0 ? (financialData.personalFinancials.personalRemaining / financialData.personalFinancials.personalAllocation) * 100 : 0}%`,
                  }}
                ></div>
                <div
                  className="bg-red-500 h-3 rounded-r-full -mt-3"
                  style={{
                    width: `${financialData.personalFinancials && financialData.personalFinancials.personalAllocation > 0 ? (financialData.personalFinancials.personalSpent / financialData.personalFinancials.personalAllocation) * 100 : 0}%`,
                    marginLeft: `${financialData.personalFinancials && financialData.personalFinancials.personalAllocation > 0 ? (financialData.personalFinancials.personalRemaining / financialData.personalFinancials.personalAllocation) * 100 : 0}%`,
                  }}
                ></div>
              </div>
            </div>
            <div className="mt-2 text-xs text-gray-500">
              Total allocation: ${financialData.personalFinancials?.totalAllocation.toFixed(2) || "0.00"}
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-green-700">Group Pool Status</CardTitle>
            <PieChart className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-800">${financialData.availableGroupFunds.toFixed(2)}</div>
            <p className="text-xs text-green-600">Available for group expenses</p>
            <div className="mt-2 space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-green-600">Available: ${financialData.availableGroupFunds.toFixed(2)}</span>
                <span className="text-red-600">
                  Spent: $
                  {(
                    financialData.totalKitty * (financialData.settings.distribution_ratio / 100) -
                    financialData.availableGroupFunds
                  ).toFixed(2)}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-green-500 h-2 rounded-l-full"
                  style={{
                    width: `${financialData.totalKitty > 0 ? (financialData.availableGroupFunds / (financialData.totalKitty * (financialData.settings.distribution_ratio / 100))) * 100 : 0}%`,
                  }}
                ></div>
                <div
                  className="bg-red-500 h-2 rounded-r-full"
                  style={{
                    width: `${financialData.totalKitty > 0 ? ((financialData.totalKitty * (financialData.settings.distribution_ratio / 100) - financialData.availableGroupFunds) / (financialData.totalKitty * (financialData.settings.distribution_ratio / 100))) * 100 : 0}%`,
                  }}
                ></div>
              </div>
            </div>
            <p className="text-xs text-purple-600 mt-2">
              Your group contribution: ${financialData.personalFinancials?.groupAllocation.toFixed(2) || "0.00"}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Add Personal Expense</CardTitle>
            <CardDescription>Track your personal spending</CardDescription>
          </div>
          <Button
            onClick={() => setShowExpenseModal(true)}
            disabled={!financialData.personalFinancials || financialData.personalFinancials.personalRemaining <= 0}
          >
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Personal Expense
          </Button>
        </CardHeader>
        {(!financialData.personalFinancials || financialData.personalFinancials.totalAllocation === 0) && (
          <CardContent>
            <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4">
              <p className="text-sm text-yellow-800">
                <strong>No allocation yet:</strong> You don't have any funds allocated to your account. Please contact
                your administrator to add funds to your allocation.
              </p>
            </div>
          </CardContent>
        )}
      </Card>

      {/* Add Expense Modal */}
      {showExpenseModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Add Personal Expense</h2>
            <div className="space-y-4">
              <div className="bg-blue-50 p-3 rounded-md">
                <p className="text-sm text-blue-800">
                  <strong>Available:</strong> $
                  {financialData.personalFinancials?.personalRemaining.toFixed(2) || "0.00"} remaining
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="expense-amount">Amount ($)</Label>
                <Input
                  id="expense-amount"
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={expenseForm.amount}
                  onChange={(e) => setExpenseForm({ ...expenseForm, amount: e.target.value })}
                  max={financialData.personalFinancials?.personalRemaining || 0}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="expense-description">Description</Label>
                <Textarea
                  id="expense-description"
                  placeholder="What was this expense for?"
                  value={expenseForm.description}
                  onChange={(e) => setExpenseForm({ ...expenseForm, description: e.target.value })}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="expense-date">Date</Label>
                <Input
                  id="expense-date"
                  type="date"
                  value={expenseForm.date}
                  onChange={(e) => setExpenseForm({ ...expenseForm, date: e.target.value })}
                  disabled={isLoading}
                />
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowExpenseModal(false)} disabled={isLoading}>
                  Cancel
                </Button>
                <Button onClick={handleAddExpense} disabled={isLoading}>
                  {isLoading ? "Adding..." : "Add Expense"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
