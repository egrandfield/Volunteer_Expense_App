"use client"

import { useEffect, useState } from "react"
import { TrendingDown, TrendingUp, RotateCcw, Trash2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"

/**
 * Props passed from the dashboard.
 */
interface Props {
  user: {
    id: number
    role: "Admin" | "Treasurer" | "Volunteer"
  }
}

/**
 * Utility to format local time strings safely.
 */
function formatDate(dateString: string) {
  const date = new Date(dateString)
  if (isNaN(date.getTime())) return "Invalid Date"
  return date.toLocaleString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
    timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
  })
}

/**
 * Financial-history view with delete / reinstate features for
 * both expenses and fund additions.
 */
export default function FinancialHistoryTab({ user }: Props) {
  const { toast } = useToast()

  /* -------------------------------------------------- */
  /* state                                              */
  /* -------------------------------------------------- */
  const [history, setHistory] = useState<any[]>([])
  const [filter, setFilter] = useState<string>("all")
  const [isLoading, setIsLoading] = useState(true)
  const [confirm, setConfirm] = useState<{ isOpen: boolean; item: any; type: string }>({
    isOpen: false,
    item: null,
    type: "",
  })

  /* -------------------------------------------------- */
  /* helpers                                            */
  /* -------------------------------------------------- */
  const reload = async () => {
    try {
      const r = await fetch("/api/financial-history")
      if (!r.ok) throw new Error("Failed to fetch history")
      let data = await r.json()

      // privacy filter for volunteers
      if (user.role === "Volunteer") {
        data = data.map((item: any) => {
          if (item.type === "fund_addition") return item
          if (item.type === "expense" && item.category === "group") return item
          if (item.type === "expense" && item.category === "personal" && item.user_id === user.id) return item
          if (item.type === "expense" && item.category === "personal") {
            return { ...item, user_name: "Team Member", description: "Personal expense" }
          }
          return item
        })
      }

      setHistory(data)
    } catch (err) {
      console.error(err)
      toast({ title: "Error", description: "Unable to load history", variant: "destructive" })
    } finally {
      setIsLoading(false)
    }
  }

  /** generic helper for expense delete / reinstate */
  const mutateExpense = async (id: string, action: "DELETE" | "PATCH", body: Record<string, unknown>) => {
    const r = await fetch(`/api/expenses/${id}`, {
      method: action,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    })
    if (!r.ok) {
      const e = await r.json()
      throw new Error(e.error ?? "Request failed")
    }
    return r.json()
  }

  /** generic helper for fund addition delete / reinstate */
  const mutateFund = async (id: string, action: "DELETE" | "PATCH", body: Record<string, unknown>) => {
    const r = await fetch(`/api/funds/${id}`, {
      method: action,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    })
    if (!r.ok) {
      const e = await r.json()
      throw new Error(e.error ?? "Request failed")
    }
    return r.json()
  }

  /* -------------------------------------------------- */
  /* permissions                                        */
  /* -------------------------------------------------- */
  const canDeleteExpense = (item: any) =>
    !item.deleted &&
    item.type === "expense" &&
    (user.role === "Admin" ||
      (user.role === "Treasurer" && item.category === "group") ||
      (item.user_id === user.id && item.category === "personal"))

  const canReinstateExpense = (item: any) =>
    item.deleted &&
    item.type === "expense" &&
    (user.role === "Admin" ||
      (user.role === "Treasurer" && item.category === "group") ||
      (item.user_id === user.id && item.category === "personal"))

  const canDeleteFund = (item: any) =>
    !item.deleted && item.type === "fund_addition" && (user.role === "Admin" || user.role === "Treasurer")

  const canReinstateFund = (item: any) =>
    item.deleted && item.type === "fund_addition" && (user.role === "Admin" || user.role === "Treasurer")

  /* -------------------------------------------------- */
  /* action handlers                                    */
  /* -------------------------------------------------- */
  const handleDeleteExpense = async (exp: any) => {
    try {
      await mutateExpense(exp.id, "DELETE", { userId: user.id, userRole: user.role })
      toast({ title: "Expense deleted", description: "Funds have been restored to user balances" })
      reload()
    } catch (err: any) {
      toast({ title: "Error deleting expense", description: err.message, variant: "destructive" })
    }
  }

  const handleReinstateExpense = async (exp: any) => {
    try {
      await mutateExpense(exp.id, "PATCH", {
        userId: user.id,
        userRole: user.role,
        action: "reinstate",
      })
      toast({ title: "Expense reinstated", description: "Funds have been deducted from user balances" })
      reload()
    } catch (err: any) {
      toast({ title: "Error reinstating expense", description: err.message, variant: "destructive" })
    }
  }

  const handleDeleteFund = async (fund: any) => {
    try {
      await mutateFund(fund.id, "DELETE", { userId: user.id, userRole: user.role })
      toast({ title: "Fund addition deleted", description: "Funds have been removed from user allocations" })
      reload()
    } catch (err: any) {
      toast({ title: "Error deleting fund addition", description: err.message, variant: "destructive" })
    }
  }

  const handleReinstateFund = async (fund: any) => {
    try {
      await mutateFund(fund.id, "PATCH", {
        userId: user.id,
        userRole: user.role,
        action: "reinstate",
      })
      toast({ title: "Fund addition reinstated", description: "Funds have been restored to user allocations" })
      reload()
    } catch (err: any) {
      toast({ title: "Error reinstating fund addition", description: err.message, variant: "destructive" })
    }
  }

  const handleDeleteClick = (item: any) => {
    // Show confirmation for group expenses and fund additions
    if ((item.type === "expense" && item.category === "group") || item.type === "fund_addition") {
      setConfirm({
        isOpen: true,
        item: item,
        type: item.type,
      })
    } else {
      // Delete personal expenses immediately
      handleDeleteExpense(item)
    }
  }

  const handleConfirmDelete = () => {
    if (confirm.item) {
      if (confirm.type === "expense") {
        handleDeleteExpense(confirm.item)
      } else if (confirm.type === "fund_addition") {
        handleDeleteFund(confirm.item)
      }
    }
    setConfirm({ isOpen: false, item: null, type: "" })
  }

  /* -------------------------------------------------- */
  /* effects                                            */
  /* -------------------------------------------------- */
  useEffect(() => {
    reload()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user.id, user.role])

  /* -------------------------------------------------- */
  /* rendering helpers                                  */
  /* -------------------------------------------------- */
  const filtered = history.filter((i) => {
    if (filter === "all") return true
    if (filter === "funds") return i.type === "fund_addition"
    if (filter === "expenses") return i.type === "expense"
    if (filter === "personal") return i.type === "expense" && i.category === "personal"
    if (filter === "group") return i.type === "expense" && i.category === "group"
    if (filter === "my-expenses") return i.type === "expense" && i.user_id === user.id
    return true
  })

  /* -------------------------------------------------- */
  /* ui                                                 */
  /* -------------------------------------------------- */
  if (isLoading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-xl font-bold mb-6">Financial History</h2>
        <p className="py-8 text-center text-gray-500">Loading…</p>
      </div>
    )
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      {/* header / filters */}
      <div className="mb-6 flex items-center justify-between">
        <h2 className="text-xl font-bold">Financial History</h2>
        <div className="flex items-center space-x-4">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Activity</SelectItem>
              <SelectItem value="funds">Fund Additions</SelectItem>
              <SelectItem value="expenses">All Expenses</SelectItem>
              {user.role === "Volunteer" ? (
                <>
                  <SelectItem value="group">Group Expenses</SelectItem>
                  <SelectItem value="my-expenses">My Expenses</SelectItem>
                </>
              ) : (
                <>
                  <SelectItem value="personal">Personal Expenses</SelectItem>
                  <SelectItem value="group">Group Expenses</SelectItem>
                </>
              )}
            </SelectContent>
          </Select>
          <p className="text-sm text-muted-foreground">
            {user.role === "Volunteer"
              ? "Team financial activity (personal details protected)"
              : "Complete financial record"}
          </p>
        </div>
      </div>

      {/* list */}
      {filtered.length === 0 ? (
        <p className="py-8 text-center text-gray-500">No activity found.</p>
      ) : (
        <div className="space-y-4">
          {filtered.map((item) => (
            <div
              key={`${item.type}-${item.id}`}
              className={`flex items-center justify-between border-b pb-4 ${item.deleted ? "bg-gray-50 opacity-50" : ""}`}
            >
              {/* left */}
              <div className="flex items-center space-x-3">
                <div
                  className={`rounded-full p-2 ${
                    item.type === "fund_addition" ? "bg-green-100 text-green-600" : "bg-red-100 text-red-600"
                  }`}
                >
                  {item.type === "fund_addition" ? (
                    <TrendingUp className="h-4 w-4" />
                  ) : (
                    <TrendingDown className="h-4 w-4" />
                  )}
                </div>
                <div>
                  <p className={`font-medium ${item.deleted ? "line-through text-gray-500" : ""}`}>
                    {item.description}
                    {item.deleted && <span className="ml-2 text-xs text-red-500">(DELETED)</span>}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {item.type === "fund_addition" ? (
                      <>
                        Added by {item.added_by_name} • {formatDate(item.created_at)}
                        {item.category === "individual" ? ` • To: ${item.user_name}` : ` • Distributed to all`}
                      </>
                    ) : (
                      <>
                        {user.role !== "Volunteer" || item.user_id === user.id ? item.user_name : "Team Member"} •{" "}
                        {formatDate(item.created_at)} • {item.category === "group" ? "Group" : "Personal"}
                      </>
                    )}
                    {item.deleted && item.deleted_at && (
                      <span className="text-red-500">{` • Deleted ${formatDate(item.deleted_at)}`}</span>
                    )}
                  </p>
                </div>
              </div>

              {/* right */}
              <div className="flex items-center space-x-2">
                <div className="text-right">
                  <p
                    className={`font-medium ${
                      item.type === "fund_addition" ? "text-green-600" : "text-red-600"
                    } ${item.deleted ? "line-through" : ""}`}
                  >
                    {item.type === "fund_addition" ? "+" : "-"}${Number(item.amount || 0).toFixed(2)}
                  </p>
                  <div
                    className={`text-xs px-2 py-1 rounded-full ${
                      item.type === "fund_addition"
                        ? item.category === "all"
                          ? "bg-green-100 text-green-800"
                          : "bg-blue-100 text-blue-800"
                        : item.category === "group"
                          ? "bg-purple-100 text-purple-800"
                          : "bg-orange-100 text-orange-800"
                    }`}
                  >
                    {item.type === "fund_addition"
                      ? item.category === "all"
                        ? "Fund Distribution"
                        : "Individual Fund"
                      : item.category === "group"
                        ? "Group Expense"
                        : "Personal Expense"}
                  </div>
                </div>

                {/* action buttons */}
                <div className="flex space-x-1">
                  {/* Delete buttons */}
                  {canDeleteExpense(item) && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-red-500 hover:bg-red-50 hover:text-red-700"
                      onClick={() => handleDeleteClick(item)}
                      title="Delete expense"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                  {canDeleteFund(item) && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-red-500 hover:bg-red-50 hover:text-red-700"
                      onClick={() => handleDeleteClick(item)}
                      title="Delete fund addition"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}

                  {/* Reinstate buttons */}
                  {canReinstateExpense(item) && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-green-500 hover:bg-green-50 hover:text-green-700"
                      onClick={() => handleReinstateExpense(item)}
                      title="Reinstate expense"
                    >
                      <RotateCcw className="h-4 w-4" />
                    </Button>
                  )}
                  {canReinstateFund(item) && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-green-500 hover:bg-green-50 hover:text-green-700"
                      onClick={() => handleReinstateFund(item)}
                      title="Reinstate fund addition"
                    >
                      <RotateCcw className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* confirm dialog for group expense and fund addition delete */}
      <AlertDialog open={confirm.isOpen} onOpenChange={(o) => setConfirm({ isOpen: o, item: null, type: "" })}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirm.type === "fund_addition" ? "Delete Fund Addition" : "Delete Group Expense"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirm.type === "fund_addition" ? (
                <>
                  Are you sure you want to delete this fund addition?
                  <br />
                  <br />
                  <strong>Description:</strong> {confirm.item?.description}
                  <br />
                  <strong>Amount:</strong> ${Number(confirm.item?.amount || 0).toFixed(2)}
                  <br />
                  <br />
                  This will remove the funds from user allocations. You can reinstate this fund addition later if
                  needed.
                </>
              ) : (
                <>
                  Are you sure you want to delete this group expense?
                  <br />
                  <br />
                  <strong>Expense:</strong> {confirm.item?.description}
                  <br />
                  <strong>Amount:</strong> ${Number(confirm.item?.amount || 0).toFixed(2)}
                  <br />
                  <br />
                  This will restore the funds proportionally to all team members. You can reinstate this expense later
                  if needed.
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={handleConfirmDelete}>
              {confirm.type === "fund_addition" ? "Delete Fund Addition" : "Delete Expense"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
