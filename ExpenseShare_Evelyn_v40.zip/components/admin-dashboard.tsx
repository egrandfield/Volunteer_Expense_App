"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { PlusCircle, Settings, DollarSign, Users } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import KittyStatus from "@/components/kitty-status"

export default function AdminDashboard({ user, onSwitchTab }: { user: any; onSwitchTab?: (tab: string) => void }) {
  const [showFundModal, setShowFundModal] = useState(false)
  const [fundAmount, setFundAmount] = useState("")
  const [showSettingsModal, setShowSettingsModal] = useState(false)
  const [showExpenseModal, setShowExpenseModal] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const [financialData, setFinancialData] = useState({
    totalKitty: 0,
    availableGroupFunds: 0,
    volunteers: [] as any[],
    settings: { distribution_ratio: 80 },
  })

  const [distributionRatio, setDistributionRatio] = useState(80)

  const [expenseForm, setExpenseForm] = useState({
    amount: "",
    description: "",
    type: "personal",
    userId: "", // Don't default to admin
    date: new Date().toISOString().split("T")[0],
  })

  const { toast } = useToast()

  const [fundDistribution, setFundDistribution] = useState("all")
  const [selectedVolunteerId, setSelectedVolunteerId] = useState("")

  // Filter out admin users from volunteers list
  const nonAdminUsers = financialData.volunteers.filter((v) => v.role !== "Admin")

  const loadFinancialData = async () => {
    try {
      const [dashboardResponse, usersResponse, settingsResponse] = await Promise.all([
        fetch("/api/dashboard"),
        fetch("/api/users"),
        fetch("/api/settings"),
      ])

      if (!dashboardResponse.ok || !usersResponse.ok || !settingsResponse.ok) {
        throw new Error("Failed to fetch data")
      }

      const [dashboardData, users, settings] = await Promise.all([
        dashboardResponse.json(),
        usersResponse.json(),
        settingsResponse.json(),
      ])

      setFinancialData({
        totalKitty: dashboardData.totalKitty,
        availableGroupFunds: dashboardData.availableGroupFunds,
        volunteers: users,
        settings,
      })
      setDistributionRatio(settings.distribution_ratio)
    } catch (error) {
      console.error("Error loading financial data:", error)
      toast({
        title: "Error loading data",
        description: "Failed to load financial information.",
        variant: "destructive",
      })
    }
  }

  useEffect(() => {
    loadFinancialData()
  }, [])

  const handleAddFunds = async () => {
    const amount = Number.parseFloat(fundAmount)
    if (!isNaN(amount) && amount > 0) {
      setIsLoading(true)
      try {
        const response = await fetch("/api/funds", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            amount,
            distribution: fundDistribution,
            userId: selectedVolunteerId || null,
            addedByUserId: user.id,
            addedByName: user.name,
          }),
        })

        if (!response.ok) {
          const error = await response.json()
          throw new Error(error.error || "Failed to add funds")
        }

        if (fundDistribution === "all") {
          toast({
            title: "Funds added",
            description: `$${amount.toFixed(2)} has been distributed evenly among ${nonAdminUsers.length} team members.`,
          })
        } else {
          const selectedVolunteer = nonAdminUsers.find((v) => v.id.toString() === selectedVolunteerId)
          toast({
            title: "Funds added",
            description: `$${amount.toFixed(2)} has been added to ${selectedVolunteer?.name}'s allocation.`,
          })
        }

        setShowFundModal(false)
        setFundAmount("")
        setFundDistribution("all")
        setSelectedVolunteerId("")
        await loadFinancialData()
      } catch (error) {
        console.error("Error adding funds:", error)
        toast({
          title: "Error adding funds",
          description: error instanceof Error ? error.message : "Failed to add funds. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }
  }

  const handleSaveSettings = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ distributionRatio }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to save settings")
      }

      setShowSettingsModal(false)
      toast({
        title: "Settings updated",
        description: "Team settings have been saved successfully.",
      })
      await loadFinancialData()
    } catch (error) {
      console.error("Error saving settings:", error)
      toast({
        title: "Error saving settings",
        description: error instanceof Error ? error.message : "Failed to save settings. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddExpense = async () => {
    const amount = Number.parseFloat(expenseForm.amount)

    if (!amount || amount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid amount greater than 0.",
        variant: "destructive",
      })
      return
    }

    if (!expenseForm.description.trim()) {
      toast({
        title: "Missing description",
        description: "Please enter a description for the expense.",
        variant: "destructive",
      })
      return
    }

    if (!expenseForm.userId) {
      toast({
        title: "No user selected",
        description: "Please select a user for this expense.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch("/api/expenses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: Number(expenseForm.userId),
          amount,
          description: expenseForm.description,
          expenseType: expenseForm.type,
          expenseDate: expenseForm.date,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        if (error.error === "Insufficient personal funds") {
          const selectedUser = nonAdminUsers.find((v) => v.id === Number(expenseForm.userId))
          toast({
            title: "Expense exceeds personal allocation",
            description: `${selectedUser?.name || "User"} only has $${error.available.toFixed(2)} remaining in their personal allocation. Maximum allowed: $${error.available.toFixed(2)}`,
            variant: "destructive",
          })
        } else if (error.error === "Insufficient group funds") {
          toast({
            title: "Expense exceeds group fund allocation",
            description: `Only $${error.available.toFixed(2)} is available for group expenses. Maximum allowed: $${error.available.toFixed(2)}`,
            variant: "destructive",
          })
        } else {
          throw new Error(error.error || "Failed to add expense")
        }
        return
      }

      // Reset form
      setExpenseForm({
        amount: "",
        description: "",
        type: "personal",
        userId: "",
        date: new Date().toISOString().split("T")[0],
      })

      setShowExpenseModal(false)
      await loadFinancialData()

      const selectedUser = nonAdminUsers.find((v) => v.id === Number(expenseForm.userId))
      toast({
        title: "Expense added",
        description: `${expenseForm.type === "group" ? "Group" : "Personal"} expense of $${amount.toFixed(2)} has been recorded for ${selectedUser?.name}.`,
      })
    } catch (error) {
      console.error("Error adding expense:", error)
      toast({
        title: "Error adding expense",
        description: error instanceof Error ? error.message : "Failed to add expense. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* User Info Header */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardContent className="pt-6">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
              {user.name
                .split(" ")
                .map((n: string) => n[0])
                .join("")
                .toUpperCase()}
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">{user.name}</h2>
              <p className="text-sm text-gray-600">{user.email}</p>
              <p className="text-sm font-medium text-blue-600">Role: {user.role}</p>
              <p className="text-xs text-blue-500">Administrator - Manages funds and expenses for team</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Kitty Status - Always shown first */}
      <KittyStatus />

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-green-700">Available Group Funds</CardTitle>
            <DollarSign className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-800">${financialData.availableGroupFunds.toFixed(2)}</div>
            <p className="text-xs text-green-600">
              {financialData.settings.distribution_ratio}% of kitty for group expenses
            </p>
            <div className="mt-2 space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-green-600">Available: ${financialData.availableGroupFunds.toFixed(2)}</span>
                <span className="text-red-600">
                  Spent: $
                  {(
                    (financialData.totalKitty * financialData.settings.distribution_ratio) / 100 -
                    financialData.availableGroupFunds
                  ).toFixed(2)}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-green-500 h-2 rounded-l-full"
                  style={{
                    width: `${financialData.totalKitty > 0 ? (financialData.availableGroupFunds / ((financialData.totalKitty * financialData.settings.distribution_ratio) / 100)) * 100 : 0}%`,
                  }}
                ></div>
                <div
                  className="bg-red-500 h-2 rounded-r-full"
                  style={{
                    width: `${financialData.totalKitty > 0 ? (((financialData.totalKitty * financialData.settings.distribution_ratio) / 100 - financialData.availableGroupFunds) / ((financialData.totalKitty * financialData.settings.distribution_ratio) / 100)) * 100 : 0}%`,
                  }}
                ></div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-orange-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-orange-700">Distribution Ratio</CardTitle>
            <Settings className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-800">
              {financialData.settings.distribution_ratio}% / {100 - financialData.settings.distribution_ratio}%
            </div>
            <p className="text-xs text-orange-600">Group / Personal expenses</p>
            <div className="mt-2 space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-green-600">Group: {financialData.settings.distribution_ratio}%</span>
                <span className="text-purple-600">Personal: {100 - financialData.settings.distribution_ratio}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 flex">
                <div
                  className="bg-green-500 h-2 rounded-l-full"
                  style={{ width: `${financialData.settings.distribution_ratio}%` }}
                ></div>
                <div
                  className="bg-purple-500 h-2 rounded-r-full"
                  style={{ width: `${100 - financialData.settings.distribution_ratio}%` }}
                ></div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button
              variant="outline"
              className="w-full"
              onClick={() => setShowSettingsModal(true)}
              disabled={isLoading}
            >
              <Settings className="mr-2 h-4 w-4" />
              Adjust Settings
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Team Members</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{nonAdminUsers.length}</div>
            <p className="text-xs text-muted-foreground">Active volunteers & treasurers</p>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full" onClick={() => onSwitchTab?.("users")}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Manage Users
            </Button>
          </CardFooter>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Team Members</CardTitle>
            <CardDescription>Current volunteers and their financial status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {nonAdminUsers.length === 0 ? (
                <p className="text-gray-500 text-center py-4">No team members added yet.</p>
              ) : (
                nonAdminUsers.map((volunteer) => (
                  <div key={volunteer.id} className="flex items-center justify-between border-b pb-2">
                    <div>
                      <p className="font-medium">{volunteer.name}</p>
                      <p className="text-sm text-muted-foreground">{volunteer.role}</p>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">${Number(volunteer.weekly_allocation).toFixed(2)}</div>
                      <div className="text-xs text-muted-foreground">
                        Personal: $
                        {(
                          (Number(volunteer.weekly_allocation) * (100 - financialData.settings.distribution_ratio)) /
                            100 -
                          Number(volunteer.personal_spent)
                        ).toFixed(2)}{" "}
                        left
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full" onClick={() => onSwitchTab?.("users")}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Manage Users
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common administrative tasks</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Button
                className="w-full"
                onClick={() => setShowExpenseModal(true)}
                disabled={isLoading || nonAdminUsers.length === 0}
              >
                <PlusCircle className="mr-2 h-4 w-4" />
                Add Expense for Team Member
              </Button>
              <Button variant="outline" className="w-full" onClick={() => setShowFundModal(true)} disabled={isLoading}>
                <DollarSign className="mr-2 h-4 w-4" />
                Add Funds to Kitty
              </Button>
              <Button
                variant="outline"
                className="w-full"
                onClick={() => setShowSettingsModal(true)}
                disabled={isLoading}
              >
                <Settings className="mr-2 h-4 w-4" />
                Adjust Team Settings
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Add Funds Modal */}
      {showFundModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Add Funds to Team</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Distribution Method</Label>
                <Select value={fundDistribution} onValueChange={(value) => setFundDistribution(value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="How to distribute funds" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Distribute evenly to all team members</SelectItem>
                    <SelectItem value="individual">Add to specific team member</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {fundDistribution === "individual" && (
                <div className="space-y-2">
                  <Label>Select Team Member</Label>
                  <Select value={selectedVolunteerId} onValueChange={(value) => setSelectedVolunteerId(value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose team member" />
                    </SelectTrigger>
                    <SelectContent>
                      {nonAdminUsers.map((volunteer) => (
                        <SelectItem key={volunteer.id} value={volunteer.id.toString()}>
                          {volunteer.name} ({volunteer.role})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="bg-blue-50 p-3 rounded-md">
                {fundDistribution === "all" ? (
                  <>
                    <p className="text-sm text-blue-800">
                      Funds will be distributed evenly among all {nonAdminUsers.length} team members
                    </p>
                    <p className="text-xs text-blue-600">
                      Each team member will receive: $
                      {fundAmount && nonAdminUsers.length > 0
                        ? (Number.parseFloat(fundAmount) / nonAdminUsers.length).toFixed(2)
                        : "0.00"}
                    </p>
                  </>
                ) : (
                  <p className="text-sm text-blue-800">Funds will be added to the selected team member's allocation</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="amount">Amount ($)</Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder="0.00"
                  value={fundAmount}
                  onChange={(e) => setFundAmount(e.target.value)}
                  disabled={isLoading}
                />
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowFundModal(false)} disabled={isLoading}>
                  Cancel
                </Button>
                <Button onClick={handleAddFunds} disabled={isLoading}>
                  {isLoading ? "Adding..." : "Add Funds"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      {showSettingsModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Team Settings</h2>
            <div className="space-y-6">
              <div className="space-y-2">
                <Label>
                  Distribution Ratio: {distributionRatio}% Group / {100 - distributionRatio}% Personal
                </Label>
                <Slider
                  value={[distributionRatio]}
                  min={0}
                  max={100}
                  step={5}
                  onValueChange={(value) => setDistributionRatio(value[0])}
                  disabled={isLoading}
                />
                <p className="text-sm text-muted-foreground">
                  Percentage of funds allocated for group vs. personal expenses
                </p>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowSettingsModal(false)} disabled={isLoading}>
                  Cancel
                </Button>
                <Button onClick={handleSaveSettings} disabled={isLoading}>
                  {isLoading ? "Saving..." : "Save Settings"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Expense Modal */}
      {showExpenseModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Add Expense for Team Member</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="expense-user">Team Member</Label>
                <Select
                  value={expenseForm.userId}
                  onValueChange={(value) => setExpenseForm({ ...expenseForm, userId: value })}
                  disabled={isLoading}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select team member" />
                  </SelectTrigger>
                  <SelectContent>
                    {nonAdminUsers.map((volunteer) => (
                      <SelectItem key={volunteer.id} value={volunteer.id.toString()}>
                        {volunteer.name} ({volunteer.role})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="expense-type">Expense Type</Label>
                <Select
                  value={expenseForm.type}
                  onValueChange={(value) => setExpenseForm({ ...expenseForm, type: value })}
                  disabled={isLoading}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select expense type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="personal">Personal Expense</SelectItem>
                    <SelectItem value="group">Group Expense</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  {expenseForm.type === "group"
                    ? `Available for group: $${financialData.availableGroupFunds.toFixed(2)}`
                    : "Will be deducted from selected team member's personal allocation"}
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="expense-amount">Amount ($)</Label>
                <Input
                  id="expense-amount"
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={expenseForm.amount}
                  onChange={(e) => setExpenseForm({ ...expenseForm, amount: e.target.value })}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="expense-description">Description</Label>
                <Textarea
                  id="expense-description"
                  placeholder="What was this expense for?"
                  value={expenseForm.description}
                  onChange={(e) => setExpenseForm({ ...expenseForm, description: e.target.value })}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="expense-date">Date</Label>
                <Input
                  id="expense-date"
                  type="date"
                  value={expenseForm.date}
                  onChange={(e) => setExpenseForm({ ...expenseForm, date: e.target.value })}
                  disabled={isLoading}
                />
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowExpenseModal(false)} disabled={isLoading}>
                  Cancel
                </Button>
                <Button onClick={handleAddExpense} disabled={isLoading}>
                  {isLoading ? "Adding..." : "Add Expense"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
