import { type NextRequest, NextResponse } from "next/server"
import { getUserFinancials } from "@/lib/database"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const userId = Number.parseInt(params.id)
    if (isNaN(userId)) {
      return NextResponse.json({ error: "Invalid user ID" }, { status: 400 })
    }

    const financials = await getUserFinancials(userId)
    if (!financials) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    return NextResponse.json(financials)
  } catch (error) {
    console.error("User financials API error:", error)
    return NextResponse.json({ error: "Failed to load user financials" }, { status: 500 })
  }
}
