import { NextResponse } from "next/server"
import { getAllUsers, createUser } from "@/lib/database"

export async function GET() {
  try {
    const users = await getAllUsers()
    return NextResponse.json(users)
  } catch (error) {
    console.error("Users API error:", error)
    return NextResponse.json({ error: "Failed to load users" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, email, role, weeklyAllocation } = body

    if (!name || !email || !role) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const user = await createUser({
      name,
      email,
      role,
      weeklyAllocation: 0, // Always start with zero, not 50
    })

    return NextResponse.json(user)
  } catch (error) {
    console.error("Create user API error:", error)
    return NextResponse.json({ error: "Failed to create user" }, { status: 500 })
  }
}
