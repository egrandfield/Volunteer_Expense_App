import { NextResponse } from "next/server"
import { updateUser, deleteUser, getUserFinancials } from "@/lib/database"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const userId = Number(params.id)
    const financials = await getUserFinancials(userId)

    if (!financials) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    return NextResponse.json(financials)
  } catch (error) {
    console.error("Get user financials API error:", error)
    return NextResponse.json({ error: "Failed to load user financials" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const userId = Number(params.id)
    const body = await request.json()
    const { name, email, role } = body

    if (!name || !email || !role) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const updatedUser = await updateUser(userId, { name, email, role })

    if (!updatedUser) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    return NextResponse.json(updatedUser)
  } catch (error) {
    console.error("Update user API error:", error)
    return NextResponse.json({ error: "Failed to update user" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const userId = Number(params.id)
    await deleteUser(userId)
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Delete user API error:", error)
    return NextResponse.json({ error: "Failed to delete user" }, { status: 500 })
  }
}
