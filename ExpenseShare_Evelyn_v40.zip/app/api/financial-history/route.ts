import { NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export async function GET() {
  try {
    // Get fund additions from fund_history table - including deleted ones
    const fundAdditions = await sql`
      SELECT 
        'fund_addition' as type,
        id,
        amount,
        description,
        distribution_type as category,
        recipient_user_id as user_id,
        recipient_name as user_name,
        added_by_user_id,
        added_by_name,
        created_at,
        COALESCE(deleted, false) as deleted,
        deleted_at,
        deleted_by_user_id
      FROM fund_history
      ORDER BY created_at DESC
    `

    // Get expenses from expenses table - including deleted ones for history
    const expenses = await sql`
      SELECT 
        'expense' as type,
        e.id,
        e.amount,
        e.description,
        e.expense_type as category,
        e.user_id,
        u.name as user_name,
        NULL as added_by_user_id,
        NULL as added_by_name,
        e.created_at,
        COALESCE(e.deleted, false) as deleted,
        e.deleted_at,
        e.deleted_by_user_id
      FROM expenses e
      JOIN users u ON e.user_id = u.id
      ORDER BY e.created_at DESC
    `

    // Combine and sort by date
    const allHistory = [...fundAdditions, ...expenses].sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime(),
    )

    return NextResponse.json(allHistory)
  } catch (error) {
    console.error("Financial history API error:", error)
    return NextResponse.json({ error: "Failed to load financial history" }, { status: 500 })
  }
}
