import { NextResponse } from "next/server"
import { addFundsToUser, getAllUsers, addFundsToAllUsers } from "@/lib/database"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { amount, distribution, userId, addedByUserId, addedByName } = body

    if (!amount || amount <= 0) {
      return NextResponse.json({ error: "Invalid amount" }, { status: 400 })
    }

    // Get all users and filter out admins
    const allUsers = await getAllUsers()
    const nonAdminUsers = allUsers.filter((user) => user.role !== "Admin")

    if (nonAdminUsers.length === 0) {
      return NextResponse.json({ error: "No team members to distribute funds to" }, { status: 400 })
    }

    if (distribution === "all") {
      await addFundsToAllUsers(amount, addedByUserId, addedByName)
    } else if (distribution === "individual" && userId) {
      // Check if the selected user is not an admin
      const selectedUser = allUsers.find((user) => user.id === Number(userId))
      if (!selectedUser) {
        return NextResponse.json({ error: "User not found" }, { status: 404 })
      }
      if (selectedUser.role === "Admin") {
        return NextResponse.json({ error: "Cannot add funds to admin accounts" }, { status: 400 })
      }

      await addFundsToUser(Number(userId), amount, addedByUserId, addedByName)
    } else {
      return NextResponse.json({ error: "Invalid distribution method" }, { status: 400 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Add funds API error:", error)
    return NextResponse.json({ error: "Failed to add funds" }, { status: 500 })
  }
}
