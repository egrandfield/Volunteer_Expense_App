import { NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const { userId, userRole } = await request.json()
    const fundId = params.id

    // Check permissions - only Treasurers and Admins can delete fund additions
    if (userRole !== "Treasurer" && userRole !== "Admin") {
      return NextResponse.json({ error: "Permission denied" }, { status: 403 })
    }

    // Get the fund addition details
    const fundResult = await sql`
      SELECT * FROM fund_history 
      WHERE id = ${fundId} AND deleted = FALSE
    `

    if (fundResult.length === 0) {
      return NextResponse.json({ error: "Fund addition not found or already deleted" }, { status: 404 })
    }

    const fund = fundResult[0]

    // Mark fund addition as deleted
    await sql`
      UPDATE fund_history 
      SET deleted = TRUE, deleted_at = CURRENT_TIMESTAMP, deleted_by_user_id = ${userId}
      WHERE id = ${fundId}
    `

    // Reverse the fund addition by reducing user allocations
    if (fund.distribution_type === "all") {
      // For "all" distribution, reduce all non-admin users' allocations
      const users = await sql`SELECT * FROM users WHERE role != 'Admin'`
      const amountPerUser = Number(fund.amount) / users.length

      for (const user of users) {
        await sql`
          UPDATE users 
          SET weekly_allocation = GREATEST(0, weekly_allocation - ${amountPerUser}), 
              updated_at = CURRENT_TIMESTAMP
          WHERE id = ${user.id}
        `
      }
    } else if (fund.distribution_type === "individual" && fund.recipient_user_id) {
      // For individual distribution, reduce specific user's allocation
      await sql`
        UPDATE users 
        SET weekly_allocation = GREATEST(0, weekly_allocation - ${fund.amount}), 
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ${fund.recipient_user_id}
      `
    }

    return NextResponse.json({
      message: `Fund addition of $${Number(fund.amount).toFixed(2)} has been deleted and funds removed from allocations`,
    })
  } catch (error) {
    console.error("Error deleting fund addition:", error)
    return NextResponse.json({ error: "Failed to delete fund addition" }, { status: 500 })
  }
}

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const { userId, userRole, action } = await request.json()
    const fundId = params.id

    if (action !== "reinstate") {
      return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }

    // Check permissions - only Treasurers and Admins can reinstate fund additions
    if (userRole !== "Treasurer" && userRole !== "Admin") {
      return NextResponse.json({ error: "Permission denied" }, { status: 403 })
    }

    // Get the deleted fund addition details
    const fundResult = await sql`
      SELECT * FROM fund_history 
      WHERE id = ${fundId} AND deleted = TRUE
    `

    if (fundResult.length === 0) {
      return NextResponse.json({ error: "Deleted fund addition not found" }, { status: 404 })
    }

    const fund = fundResult[0]

    // Mark fund addition as not deleted
    await sql`
      UPDATE fund_history 
      SET deleted = FALSE, deleted_at = NULL, deleted_by_user_id = NULL
      WHERE id = ${fundId}
    `

    // Re-add the fund allocation
    if (fund.distribution_type === "all") {
      // For "all" distribution, add back to all non-admin users' allocations
      const users = await sql`SELECT * FROM users WHERE role != 'Admin'`
      const amountPerUser = Number(fund.amount) / users.length

      for (const user of users) {
        await sql`
          UPDATE users 
          SET weekly_allocation = weekly_allocation + ${amountPerUser}, 
              updated_at = CURRENT_TIMESTAMP
          WHERE id = ${user.id}
        `
      }
    } else if (fund.distribution_type === "individual" && fund.recipient_user_id) {
      // For individual distribution, add back to specific user's allocation
      await sql`
        UPDATE users 
        SET weekly_allocation = weekly_allocation + ${fund.amount}, 
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ${fund.recipient_user_id}
      `
    }

    return NextResponse.json({
      message: `Fund addition of $${Number(fund.amount).toFixed(2)} has been reinstated and funds restored to allocations`,
    })
  } catch (error) {
    console.error("Error reinstating fund addition:", error)
    return NextResponse.json({ error: "Failed to reinstate fund addition" }, { status: 500 })
  }
}
