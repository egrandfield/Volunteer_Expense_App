import { NextResponse } from "next/server"
import { getSettings, updateSettings } from "@/lib/database"

export async function GET() {
  try {
    const settings = await getSettings()
    return NextResponse.json(settings)
  } catch (error) {
    console.error("Settings API error:", error)
    return NextResponse.json({ error: "Failed to load settings" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { distributionRatio } = body

    if (distributionRatio < 0 || distributionRatio > 100) {
      return NextResponse.json({ error: "Invalid distribution ratio" }, { status: 400 })
    }

    await updateSettings(distributionRatio)
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Update settings API error:", error)
    return NextResponse.json({ error: "Failed to update settings" }, { status: 500 })
  }
}
