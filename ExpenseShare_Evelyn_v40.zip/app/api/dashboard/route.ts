import { NextResponse } from "next/server"
import { getTotalKitty, getAvailableGroupFunds, getAllUsers, getSettings } from "@/lib/database"

export async function GET() {
  try {
    const [totalKitty, availableGroupFunds, users, settings] = await Promise.all([
      getTotalKitty(),
      getAvailableGroupFunds(),
      getAllUsers(),
      getSettings(),
    ])

    return NextResponse.json({
      totalKitty,
      availableGroupFunds,
      totalUsers: users.length,
      settings,
      users,
    })
  } catch (error) {
    console.error("Dashboard API error:", error)
    return NextResponse.json({ error: "Failed to load dashboard data" }, { status: 500 })
  }
}
