import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params
    const { userId, userRole } = await request.json()

    // Get the expense details first
    const expense = await sql`
      SELECT e.*, u.name as user_name
      FROM expenses e
      JOIN users u ON e.user_id = u.id
      WHERE e.id = ${id}
    `

    if (expense.length === 0) {
      return NextResponse.json({ error: "Expense not found" }, { status: 404 })
    }

    const expenseData = expense[0]

    // Check permissions
    const canDelete =
      userRole === "Admin" || // Admin can delete any expense
      (userRole === "Treasurer" && expenseData.expense_type === "group") || // Treasurer can delete group expenses
      (expenseData.user_id === userId && expenseData.expense_type === "personal") // Users can delete their own personal expenses

    if (!canDelete) {
      return NextResponse.json({ error: "Insufficient permissions to delete this expense" }, { status: 403 })
    }

    // Mark expense as deleted instead of actually deleting it
    await sql`
      UPDATE expenses 
      SET deleted = true, deleted_at = CURRENT_TIMESTAMP, deleted_by_user_id = ${userId}
      WHERE id = ${id}
    `

    // Restore funds based on expense type
    if (expenseData.expense_type === "personal") {
      // Restore personal funds to the user
      await sql`
        UPDATE users 
        SET personal_spent = personal_spent - ${expenseData.amount}
        WHERE id = ${expenseData.user_id}
      `
    } else if (expenseData.expense_type === "group") {
      // Restore group funds by reducing everyone's group_spent proportionally
      const users = await sql`SELECT id FROM users`
      const amountPerUser = Number(expenseData.amount) / users.length

      await sql`
        UPDATE users 
        SET group_spent = group_spent - ${amountPerUser}
      `
    }

    return NextResponse.json({
      success: true,
      message: `${expenseData.expense_type === "group" ? "Group" : "Personal"} expense deleted and funds restored`,
    })
  } catch (error) {
    console.error("Delete expense API error:", error)
    return NextResponse.json({ error: "Failed to delete expense" }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params
    const { userId, userRole, action } = await request.json()

    if (action !== "reinstate") {
      return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }

    // Get the expense details first
    const expense = await sql`
      SELECT e.*, u.name as user_name
      FROM expenses e
      JOIN users u ON e.user_id = u.id
      WHERE e.id = ${id} AND e.deleted = true
    `

    if (expense.length === 0) {
      return NextResponse.json({ error: "Deleted expense not found" }, { status: 404 })
    }

    const expenseData = expense[0]

    // Check permissions (same as delete permissions)
    const canReinstate =
      userRole === "Admin" || // Admin can reinstate any expense
      (userRole === "Treasurer" && expenseData.expense_type === "group") || // Treasurer can reinstate group expenses
      (expenseData.user_id === userId && expenseData.expense_type === "personal") // Users can reinstate their own personal expenses

    if (!canReinstate) {
      return NextResponse.json({ error: "Insufficient permissions to reinstate this expense" }, { status: 403 })
    }

    // Check if user has enough funds to reinstate
    if (expenseData.expense_type === "personal") {
      // Get user's current allocation and spending
      const user = await sql`
        SELECT weekly_allocation, personal_spent 
        FROM users 
        WHERE id = ${expenseData.user_id}
      `

      if (user.length === 0) {
        return NextResponse.json({ error: "User not found" }, { status: 404 })
      }

      // Get settings to calculate personal allocation
      const settings = await sql`
        SELECT distribution_ratio FROM settings ORDER BY created_at DESC LIMIT 1
      `
      const distributionRatio = settings.length > 0 ? settings[0].distribution_ratio : 80
      const personalPercentage = (100 - distributionRatio) / 100

      const personalAllocation = Number(user[0].weekly_allocation) * personalPercentage
      const personalSpent = Number(user[0].personal_spent)
      const availablePersonal = personalAllocation - personalSpent

      if (availablePersonal < Number(expenseData.amount)) {
        return NextResponse.json(
          {
            error: `Insufficient personal funds. Available: $${availablePersonal.toFixed(2)}, Required: $${Number(expenseData.amount).toFixed(2)}`,
          },
          { status: 400 },
        )
      }
    } else if (expenseData.expense_type === "group") {
      // Check if there are enough group funds available
      // Get total kitty and current group spending
      const kittyResult = await sql`
        SELECT COALESCE(SUM(weekly_allocation), 0) as total_kitty
        FROM users
      `
      const totalKitty = Number(kittyResult[0].total_kitty)

      const groupSpentResult = await sql`
        SELECT COALESCE(SUM(group_spent), 0) as total_group_spent
        FROM users
      `
      const totalGroupSpent = Number(groupSpentResult[0].total_group_spent)

      // Get settings to calculate group allocation
      const settings = await sql`
        SELECT distribution_ratio FROM settings ORDER BY created_at DESC LIMIT 1
      `
      const distributionRatio = settings.length > 0 ? settings[0].distribution_ratio : 80
      const groupPercentage = distributionRatio / 100

      const maxGroupFunds = totalKitty * groupPercentage
      const availableGroupFunds = maxGroupFunds - totalGroupSpent

      if (availableGroupFunds < Number(expenseData.amount)) {
        return NextResponse.json(
          {
            error: `Insufficient group funds. Available: $${availableGroupFunds.toFixed(2)}, Required: $${Number(expenseData.amount).toFixed(2)}`,
          },
          { status: 400 },
        )
      }
    }

    // Reinstate the expense
    await sql`
      UPDATE expenses 
      SET deleted = false, deleted_at = NULL, deleted_by_user_id = NULL, reinstated_at = CURRENT_TIMESTAMP, reinstated_by_user_id = ${userId}
      WHERE id = ${id}
    `

    // Deduct funds again based on expense type
    if (expenseData.expense_type === "personal") {
      // Deduct personal funds from the user
      await sql`
        UPDATE users 
        SET personal_spent = personal_spent + ${expenseData.amount}
        WHERE id = ${expenseData.user_id}
      `
    } else if (expenseData.expense_type === "group") {
      // Deduct group funds by increasing everyone's group_spent proportionally
      const users = await sql`SELECT id FROM users`
      const amountPerUser = Number(expenseData.amount) / users.length

      await sql`
        UPDATE users 
        SET group_spent = group_spent + ${amountPerUser}
      `
    }

    return NextResponse.json({
      success: true,
      message: `${expenseData.expense_type === "group" ? "Group" : "Personal"} expense reinstated and funds deducted`,
    })
  } catch (error) {
    console.error("Reinstate expense API error:", error)
    return NextResponse.json({ error: "Failed to reinstate expense" }, { status: 500 })
  }
}
