import { NextResponse } from "next/server"
import {
  createExpense,
  addPersonalExpense,
  addGroupExpenseToAllUsers,
  getUserFinancials,
  getAvailableGroupFunds,
} from "@/lib/database"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { userId, amount, description, expenseType, expenseDate } = body

    if (!userId || !amount || !description || !expenseType) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    if (amount <= 0) {
      return NextResponse.json({ error: "Invalid amount" }, { status: 400 })
    }

    // Check if user has sufficient funds
    if (expenseType === "personal") {
      const userFinancials = await getUserFinancials(Number(userId))
      if (!userFinancials || amount > userFinancials.personalRemaining) {
        return NextResponse.json(
          {
            error: "Insufficient personal funds",
            available: userFinancials?.personalRemaining || 0,
          },
          { status: 400 },
        )
      }
      await addPersonalExpense(Number(userId), amount)
    } else {
      const availableGroupFunds = await getAvailableGroupFunds()
      if (amount > availableGroupFunds) {
        return NextResponse.json(
          {
            error: "Insufficient group funds",
            available: availableGroupFunds,
          },
          { status: 400 },
        )
      }
      await addGroupExpenseToAllUsers(amount)
    }

    // Create expense record
    const expense = await createExpense({
      userId: Number(userId),
      amount,
      description,
      expenseType: expenseType as "personal" | "group",
      expenseDate: expenseDate || new Date().toISOString().split("T")[0],
    })

    return NextResponse.json(expense)
  } catch (error) {
    console.error("Create expense API error:", error)
    return NextResponse.json({ error: "Failed to create expense" }, { status: 500 })
  }
}
