"use client"
import { useRouter } from "next/navigation"
import LoginForm from "@/components/login-form"

export default function Home() {
  const router = useRouter()

  const handleLogin = (user: any) => {
    // Store user in localStorage for session management
    localStorage.setItem("user", JSON.stringify(user))
    router.push("/dashboard")
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-50">
      <div className="w-full max-w-md space-y-8 p-8 bg-white rounded-lg shadow-md">
        <div className="text-center">
          <h1 className="text-3xl font-bold">ExpenseShare</h1>
          <p className="mt-2 text-gray-600">Track and manage shared expenses</p>
          <p className="mt-1 text-sm text-gray-500">Default admin: admin@expenseshare.com</p>
        </div>
        <LoginForm onLogin={handleLogin} />
      </div>
    </div>
  )
}
